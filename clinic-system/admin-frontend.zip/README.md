# Admin Portal — React Components (Phase 7: Reports)

Matches the same `Clinical Clarity Glass` design system as the
receptionist portal — reuses the same theme CSS and toast provider.

## Files

```
api/adminApi.js                    — fetch wrapper for admin endpoints (Reports for now)
components/admin/
  AdminLayout.jsx                  — sidebar + header shell (nav has just "Reports" — extend as you build more admin pages)
  Reports.jsx                      — the Phase 7 Reports dashboard

styles/receptionist-theme.css      — same theme file as the receptionist package (duplicated here for convenience — it's the identical file, safe to only keep one copy in your actual src tree)
components/shared/ToastProvider.jsx — same as the receptionist package, same reasoning
```

## Wiring in

```jsx
import AdminLayout from './components/admin/AdminLayout';
import Reports from './components/admin/Reports';

<Route path="/admin" element={<AdminLayout user={user} />}>
  <Route path="reports" element={<Reports token={token} />} />
  {/* add more admin routes here as you build Doctors/Patients/Billing pages */}
</Route>
```

Same `token` prop convention as the receptionist components.

## Scope

Only **Reports** is built. `AdminLayout`'s nav intentionally has just
one item — I don't know what your existing admin UI looks like (you've
only ever shown me receptionist mockups), so I didn't want to invent
Doctors/Patients/Billing nav links that point at pages that don't exist
as React screens yet. Add `NavLink`s to `AdminLayout.jsx` the same way
`ReceptionistLayout.jsx` does, as those get built.

## Chart

The monthly revenue chart is a small dependency-free inline SVG bar
chart (see `RevenueBarChart` inside `Reports.jsx`) — not recharts/
chart.js, since I don't know if either is installed in your actual
project. Swap it for your existing chart component if you have one; the
data shape it expects is `[{ label: 'Mar 2026', amount: 6100 }, ...]`,
which is exactly what `GET /api/admin/reports/overview`'s
`revenue.monthly` returns.
