/**
 * adminApi.js
 *
 * Same fetch pattern as receptionistApi.js — see that file's header
 * comment for the token/API_BASE notes, which apply here too.
 *
 * Only wraps the Reports endpoint for now. Extend this the same way as
 * more admin API routes (doctors, patients, billing) get frontend pages.
 */

const API_BASE = '/api';

async function request(path, { method = 'GET', body, token } = {}) {
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  let data = null;
  try {
    data = await res.json();
  } catch (e) {
    // no body
  }

  if (!res.ok) {
    const error = new Error(data?.message || `Request failed (${res.status})`);
    error.status = res.status;
    throw error;
  }

  return data;
}

export function createAdminApi(token) {
  const opts = (extra = {}) => ({ ...extra, token });

  return {
    getReportsOverview: () => request('/admin/reports/overview', opts()),
    getBillingSummary: () => request('/admin/billing/summary', opts()),
    getInvoices: (params = {}) => {
      const qs = new URLSearchParams(params).toString();
      return request(`/admin/billing/invoices${qs ? `?${qs}` : ''}`, opts());
    },
  };
}
