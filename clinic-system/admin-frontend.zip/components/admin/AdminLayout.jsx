import React, { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import '../../styles/receptionist-theme.css';
import { ToastProvider } from '../shared/ToastProvider';

/**
 * AdminLayout
 *
 * Same shell pattern as ReceptionistLayout (same theme CSS, same
 * ToastProvider), scoped down to what's actually built: only "Reports"
 * is a real page right now. The nav is intentionally short rather than
 * linking to Doctors/Patients/Billing pages that don't exist yet as
 * React screens — add NavLinks here as those get built, following the
 * same pattern as ReceptionistLayout's nav.
 *
 *   <Route path="/admin" element={<AdminLayout user={user} />}>
 *     <Route path="reports" element={<Reports token={token} />} />
 *   </Route>
 */
export default function AdminLayout({ user }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems = [
    { to: '/admin/reports', label: 'Reports', icon: IconChart },
  ];

  return (
    <ToastProvider>
      <div className="mg-app">
        <div className="mg-shell">
          {sidebarOpen && (
            <div className="mg-sidebar-backdrop" onClick={() => setSidebarOpen(false)} aria-hidden="true" />
          )}

          <aside className={`mg-sidebar ${sidebarOpen ? 'open' : ''}`}>
            <div className="mg-sidebar-brand">
              <div className="mg-sidebar-brand-icon">
                <IconCross />
              </div>
              <div>
                <div className="mg-sidebar-brand-title">MediGlass Portal</div>
                <div className="mg-sidebar-brand-subtitle">Admin View</div>
              </div>
            </div>

            <nav className="mg-nav">
              {navItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={({ isActive }) => `mg-nav-item ${isActive ? 'active' : ''}`}
                  onClick={() => setSidebarOpen(false)}
                >
                  <item.icon className="mg-nav-icon" />
                  {item.label}
                </NavLink>
              ))}
            </nav>
          </aside>

          <div className="mg-main">
            <header className="mg-header">
              <button
                type="button"
                className="mg-icon-btn mg-mobile-menu-btn"
                aria-label="Open menu"
                aria-expanded={sidebarOpen}
                onClick={() => setSidebarOpen((v) => !v)}
              >
                <IconMenu />
              </button>

              <div className="mg-header-spacer" />

              {user?.avatarUrl ? (
                <img className="mg-avatar" src={user.avatarUrl} alt={user?.name || 'Account'} />
              ) : (
                <div
                  className="mg-avatar"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: 'var(--mg-secondary-container)',
                    color: 'var(--mg-primary)',
                    fontWeight: 700,
                  }}
                >
                  {(user?.name || 'A')[0].toUpperCase()}
                </div>
              )}
            </header>

            <main className="mg-content">
              <Outlet />
            </main>
          </div>
        </div>
      </div>
    </ToastProvider>
  );
}

function IconCross(props) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" {...props}>
      <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}
function IconChart({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none">
      <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function IconMenu() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}
